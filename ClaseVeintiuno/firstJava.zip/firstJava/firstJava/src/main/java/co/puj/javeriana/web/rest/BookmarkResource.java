package co.puj.javeriana.web.rest;
import co.puj.javeriana.web.persistence.BookmarkDB;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sweb on 18/10/2016.
 */


@RestController
public class BookmarkResource {

    BookmarkDB bookmarkDB;

    public BookmarkResource(BookmarkDB bookmarkDB) {
        this.bookmarkDB = bookmarkDB;
    }

    @GetMapping(value = "/rest/bookmarks")
    public List<Bookmark> getAll(){
        return bookmarkDB.findAll();
    }

    @PostMapping(value = "/rest/bookmarks")
    public void insert(@RequestBody Bookmark bookmark){
        bookmarkDB.save(bookmark);
    }

    @DeleteMapping(value = "/rest/bookmarks/{id}")
    public void delete (@PathVariable("id") long id){
        bookmarkDB.delete(id);
    }

    @PutMapping(value = "/rest/bookmarks")
    public void update (@RequestBody Bookmark bookmark){
        bookmarkDB.save(bookmark);
    }

    @GetMapping(value = "/rest/bookmarks/{id}")
    public  Bookmark getById (@PathVariable("id") long id){
        return bookmarkDB.findOne(id);
    }
}
