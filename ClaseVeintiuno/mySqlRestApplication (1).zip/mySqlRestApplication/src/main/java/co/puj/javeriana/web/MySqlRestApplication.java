package co.puj.javeriana.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySqlRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySqlRestApplication.class, args);
	}
}
