//my sql configuration
var mysql = require('mysql');
var exports = module.exports = {};

var pool  = mysql.createPool({
  connectionLimit : 10,
  host            : '33.33.33.10',
  user            : 'bookmarks',
  password        : 'bookmarks',
  database        : 'bookmarks'
});

exports.executeSqlFunction = function(funct) {
    pool.getConnection(function(err, connection) {
        if (err) throw err;

        funct(connection);
        connection.release();
    });
}